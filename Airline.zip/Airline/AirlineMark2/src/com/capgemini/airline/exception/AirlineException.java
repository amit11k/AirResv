package com.capgemini.airline.exception;

public class AirlineException extends Exception{
	public AirlineException(String msg) {
		super(msg);
	}
}
