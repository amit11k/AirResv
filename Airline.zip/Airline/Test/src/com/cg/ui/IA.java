package com.cg.ui;

public class IA {
	int a=10;
	public IA() {
		System.out.println("In cons IA");
	}
	public IA(int x){
		System.out.println("x:"+x);
	}
}
