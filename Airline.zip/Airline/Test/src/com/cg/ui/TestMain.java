package com.cg.ui;

public class TestMain {

	public static void main(String[] args) {
		
		IA ref1 = new A();
	}
}
